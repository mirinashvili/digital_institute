

// დავალება #1

// function array (arr1, arr2) {
  
//     for (var i = 0; i < arr1.length; i++) {

//       if (arr1[i] !== arr2[i]) return false;
//     }
  
//     return true;
//   }

//   console.log(array([1,2,3,4], [1,2,3,4]));




// დავალება #2

// function array (arr1, arr2) {

//     for (let i = 0; i < arr1.length; i++) {

//         if (!arr2.includes(arr1[i])) {

//           return false;
//         }
//       }
    
//       return true;

// }

// console.log(array ([1,2,3,4,], [3,2,4,1]));