
// დავალება #1
// const title = document.getElementById ('title')
// let btn = document.getElementById ('btn')

// btn.addEventListener ('click', function () {
//     title.innerHTML = 'mamuka'
// })

// ----------------------------------

// დავალება #2

// const mainBtn = document.getElementById ('mainBtn')

// const btn = document.querySelectorAll ('.btn')

// mainBtn.addEventListener ('click', function () {
//     btn.forEach (function (btns) {
//         const randomColor = "#" + Math.floor(Math.random() * 16777215).toString(16);
//         btns.style.backgroundColor = randomColor
//     })
// })

// ---------------------------------

// დავალება #3

// const paragraf = document.getElementById ('para');

// const pluse = document.getElementById('btnPlus')
// const minus = document.getElementById('btnMinus')

// let paragrafs = 0

// pluse.addEventListener ('click', function () {

//    paragrafs ++
//    paragraf.innerHTML = paragrafs

//    if (paragraf.innerHTML % 2 === 0) {
//      paragraf.style.color = 'red'
//    } else {
//      paragraf.style.color = 'blue'
//    }

// })

// minus.addEventListener ('click', function () {
 
//     paragrafs --
//     paragraf.innerHTML = paragrafs

//     if (paragraf.innerHTML % 2 === 0) {
//         paragraf.style.color = 'red'
//       } else {
//         paragraf.style.color = 'blue'
//       }

//  })